<?php
include "utils/usuarios_funcoes.php";

$id = $_GET["id"];

if(deletarUsuario($id))
{
	echo "<h1> Usuario Deletado com Sucesso </h1>";
}
else
{
	echo "<h1> Falhou ao Deletar</h1>";
}
?>
<center><a href="usuarios.php">Voltar</a></center>