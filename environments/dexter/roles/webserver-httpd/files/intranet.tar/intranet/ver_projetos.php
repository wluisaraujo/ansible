<?php
include "templates/topo.php";
include_once "utils/projetos_funcoes.php";

if(!isset($_GET['id']))
{
	echo "Projeto nao encontrado";
}
else
{
	$projeto = selecionarProjetosPorId($_GET['id']);
}
?>
<div class="container">
  <div class="row">
    <div class="container col-lg-6">
      <div class="panel panel-info">
        <div class="panel panel-heading">Objetivo</div>
        <div class="panel panel-body">
            <?php echo $projeto["objetivo"]; ?>
        </div>
      </div>
      <div class="panel panel-primary">
        <div class="panel panel-heading">Cenário Proposto</div>
        <div class="panel panel-body">
            <?php echo $projeto["proposto"]; ?>
        </div>
      </div>
      <div class="panel panel-success">
        <div class="panel panel-heading">Cenário Atual</div>
        <div class="panel panel-body">
            <?php echo $projeto["atual"]; ?>
        </div>
      </div>
    </div>
    <div class="container col-lg-6">
      <div class="panel panel-default">
        <div class="panel panel-heading">Detalhes</div>
        <div class="panel panel-body">
            <div class="input-group">
              <span class="input-group-addon">
                <span class="glyphicon glyphicon-user"> Cliente</span>
              </span>
              <input type='text' class="form-control"
              value='<?php echo $projeto["cliente"] ?>' />
            </div> <br/>
            <div class="input-group">
              <span class="input-group-addon">
                <span class="glyphicon glyphicon-time"> Data Entrega</span>
              </span>
              <input type='text' class="form-control"
              value='<?php echo $projeto["data_entrega"] ?>' />
            </div><br/>  
            <?php if($projeto['status'] != 1){ ?>
            <div class="form-inline">
                <div class="form-group">
                  <a href="aceite.php?id=<?php echo $projeto['id']; ?>&status=1" 
                    class="btn btn-success">Aprovar</a>
                </div>
                <div class="form-group">
                  <a href="aceite.php?id=<?php echo $projeto['id']; ?>&status=2" 
                    class="btn btn-danger">Reprovar</a>
                </div>
            </div>  
            <?php } ?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php
include "templates/rodape.php";
?>
