<?php
include "utils/clientes_funcoes.php";

$id = $_GET["id"];

if(deletarCliente($id))
{
	echo "<h1> Cliente Deletado com Sucesso </h1>";
}
else
{
	echo "<h1> Falhou ao Deletar</h1>";
}
?>
<center><a href="clientes.php">Voltar</a></center>
