<nav class="navbar navbar-inverse navbar-bottom" style="margin-bottom: 0px;">
    <h4>Ferramenta de Projetos Desenvolvida no Curso de PHP</h4>
</nav>
<link rel="stylesheet"  href="static/css/bootstrap.min.css" />
</body>
</html>
