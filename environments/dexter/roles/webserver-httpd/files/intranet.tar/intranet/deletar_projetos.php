<?php

include "utils/projetos_funcoes.php";

if(deletarProjeto($_GET["id"]))
{
echo "<h1> Projeto removido com sucesso!</h1>";
}
else
{
	echo "<h1> Erro ao remover projeto</h1>";
}
echo "<center><a href='projetos.php'>Voltar</a></center>";
?>
