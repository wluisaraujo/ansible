<?php
include_once "database.php";

function listaUsuarios()
{
	$con = conectaBanco();
	$result = mysqli_query($con,"select * from usuarios");
	return $result; 
}

function inserirUsuario($nome,$email,$senha)
{
	$con = conectaBanco();
	$result = mysqli_query($con,"insert into usuarios(nome,email,senha)
								values ('".$nome."',
									    '".$email."',
									    '".$senha,"')");
	return $result;
}

function novoUsuario()
{
	$dados = array(
					"id"=>"",
					"nome"=>"",
					"email"=>"",
					"senha"=>"",
					"url"=>"salvar_usuarios.php",
				);
	return $dados;
}

function salvarUsuario($nome,$email,$senha)
{
	$con = conectaBanco();
	$result = mysqli_query($con,"insert into usuarios(nome,email,senha)
								 values('".$nome."',
								 		'".$email."',
								 		'".$senha."')");
	return $result;
}

function obterUsuario($email)
{
	$con = conectaBanco();
	$result = mysqli_query($con,"select * from usuarios
								 where email='".$email."'");
	$r = mysqli_fetch_assoc($result);
	return $r;
}

function editarUsuario($usuario_id)
{
	$con = conectaBanco();
	$usuario = mysqli_query($con,"select * from usuarios
							 where id=".$usuario_id);
	$usuario_array = mysqli_fetch_assoc($usuario);
	$usuario_array["url"] = "atualizar_usuarios.php";
	return $usuario_array;
}

function atualizarUsuario($usuario_id,$nome,$email,$senha)
{
	$con = conectaBanco();
	$result = mysqli_query($con,"update usuarios set
								 nome='".$nome."',
								 email='".$email."',
								 senha='".$senha."'
								 where id=".$usuario_id);
	return $result;
}

function deletarUsuario($usuario_id)
{
	$con = conectaBanco();
	$result = mysqli_query($con,"delete from usuarios
								 where id=".$usuario_id);
	return $result;
}
?>
