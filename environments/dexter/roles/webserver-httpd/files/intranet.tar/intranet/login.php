<html>
<head><title>Login</title></head>
<body>

<div class="container">
	<div class="row">
		<div class="col-lg-4">
			<div class="panel panel-warning">
				<div class="panel panel-heading">Login</div>
				<div class="panel panel-body">
				<form method="post" action="fazer_login.php" class="form-horizontal">
					<div class="form-group">
						<label class="col-sm-2">Email</label>
						<div class="col-sm-10">
							<input type="email" name="email" class="form-control" placeholder="Digite seu email"/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2">Senha</label>
						<div class="col-sm-10">
							<input type="password" name="senha" class="form-control" placeholder="Digite seu email"/>
						</div>
					</div>
					<input type="submit" class="btn btn-default" value="Logar" />
				</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include "templates/rodape.php"; ?>