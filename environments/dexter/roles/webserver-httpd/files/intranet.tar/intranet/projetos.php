<?php
include "templates/topo.php";
include "utils/projetos_funcoes.php";

if(!isset($_GET['inicial']) or !isset($_GET['final'])){ 
  $inicial = 1;
  $final = 5;
}
else{
  $inicial = $_GET['inicial'];
  $final = $_GET['final'];
}
$result = listaProjetos($inicial,$final);

?>
<div class="container">
  <a class="btn btn-success" href="cadastrar_projetos.php">Novo</a>
  <br/>
  <table class="table table-striped">
    <th>ID</th>
    <th>Nome</th>
    <th>Cliente</th>
    <th>Data Entrega</th>
    <th>Valor</th>
    <th>Ações</th>
    <?php foreach($result as $p ) {?>
    <tr>
      <td><?php echo $p['id']?></td>
      <td><?php echo $p['nome']?></td>
      <td><?php echo $p['cliente']?></td>
      <td><?php echo $p['data_entrega']?></td>
      <td><?php echo $p['valor']?></td>
      <td>
        <a class="btn btn-success" href="cadastrar_projetos.php?editar=<?php echo $p["id"]; ?>" >Editar</a>
        <a class="btn btn-danger" 
           href="deletar_projetos.php?id=<?php echo $p['id']; ?>">
           Deletar
          <span class="glyphicon glyphicon-remove"></span>
        </a>
      </td>
    </tr>
    <?php } ?>
  </table>
  <center>
    <a href="projetos.php">1</a>&nbsp
    <a href="projetos.php?inicial=6&final=11">2</a>&nbsp
    <a href="projetos.php?inicial=12&final=17">3</a></center>
</div>


<?php
include "templates/rodape.php";
?>
