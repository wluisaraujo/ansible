<?php

function conectaBanco() {

	$con = mysqli_connect("127.0.0.1",
      "root", "123456", "portaldexter")
	 	 or die("Nao foi possivel conectar com o banco de dados");

	return $con;
}

?>
