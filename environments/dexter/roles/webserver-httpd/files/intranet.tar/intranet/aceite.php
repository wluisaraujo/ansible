<?php
include "templates/topo.php";
include_once "utils/projetos_funcoes.php";
if(!isset($_GET['id']) && !isset($_GET['status']))
{
	echo "Parametros invalidos";
}
else
{
	$aceite = aceiteProjeto($_GET['id'],$_GET['status']);
	if($aceite)
	{
		echo "<center><h1>Projeto Atualizado com sucesso!</h1></center>";
	}
	else
	{
		echo "<center><h1>Erro!</h1></center>";	
	}
}
?>

<center><a href="index.php">Voltar</a></center>
<?php
include "templates/rodape.php";
?>