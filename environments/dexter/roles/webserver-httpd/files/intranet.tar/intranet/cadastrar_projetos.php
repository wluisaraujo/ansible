<?php
include "templates/topo.php";
include "utils/projetos_funcoes.php";

if(isset($_GET["editar"]))
{
  $dados = editarProjeto($_GET["editar"]);
}
else
{
  $dados = cadastrarProjeto();
}

?>
<div class="container">
  <form method="POST" action="<?php echo $dados["url"] ?>" class="form-horizontal">
    <div class="form-group">
      <label class="col-sm-2">Nome</label>
      <div class="col-sm-10">
        <input type="text" name="nome" class="form-control" 
        value="<?php echo $dados["nome"] ?>" placeholder="Digite o nome do Projeto"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Cliente</label>
      <div class="col-sm-10">
          <select name="cliente">
              <?php
                echo selecionarCliente($dados["cliente"]);
              ?>
          </select>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Data de Entrega</label>
      <div class="col-sm-10">
        <input type="text" name="data_entrega" class="form-control" 
        value="<?php echo $dados['data_entrega'] ?>" placeholder="Data de Entrega do Projeto"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Valor</label>
      <div class="col-sm-10">
        <input type="text" name="valor" class="form-control" 
        value="<?php echo $dados['valor'] ?>" placeholder="Valor do Projeto"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Objetivo</label>
      <div class="col-sm-10">
        <textarea class="form-control" name="objetivo" 
          cols="20" rows="2" placeholder="Objetivo do Projeto"><?php echo $dados['objetivo'] ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Cenário Atual</label>
      <div class="col-sm-10">
        <textarea class="form-control" name="atual" 
          cols="20" rows="2" placeholder="Descreva o cenário atual"><?php echo $dados['atual'] ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Cenário Proposto</label>
      <div class="col-sm-10">
        <textarea class="form-control" name="proposto" 
          cols="20" rows="2" placeholder="Descreva o cenário Proposto"><?php echo $dados['proposto'] ?></textarea>
      </div>
    </div>
    <input type="hidden" name="id" value="<?php echo $dados['id'] ?>" />
    <input type="submit" class="btn btn-primary" value="Salvar" />
  </form>
</div>
<?php
include "templates/rodape.php";
?>
