<?php 

$id = (int) $_POST["id"];
$nome = $_POST["nome"];
$cliente = $_POST["cliente"];
$data_entrega = $_POST["data_entrega"];
$valor = (float) $_POST["valor"];

$con = mysqli_connect("127.0.0.1","projetos","4linux","projetos");
$result = mysqli_query($con,"update projetos
						set nome='".$nome."',
						    cliente='".$cliente."',
						    data_entrega='".$data_entrega."',
						    valor=".$valor."
						    where id=".$id);
if($result)
{
	echo "<h1> Cadastro Atualizado com Sucesso! </h1>";
}
else
{
	echo "<h1> Falhou ao atualizar </h1>";
}
?>
<center><a href="projetos.php">Voltar</a></center>

<?php 
include "templates/rodape.php";
?>