<?php 
include "utils/usuarios_funcoes.php";

$id = (int) $_POST["id"];
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

if(atualizarUsuario($id,$nome,$email,$senha))
{
	echo "<h1> Cadastro atualizado com Sucesso! </h1>";
}
else
{
	echo "<h1> Falhou atualizar </h1>";
}
?>
<center><a href="usuarios.php">Voltar</a></center>

<?php 
include "templates/rodape.php";
?>