#include <stdio.h>

int main(){
	printf("\nOi! Eu sou um programa compilado :)\n\n");
}
