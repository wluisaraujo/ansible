<?php
include "templates/topo.php";
include "utils/clientes_funcoes.php";
if(isset($_GET["editar"]))
{
  $dados = editarCliente($_GET["editar"]);
}
else
{
  $dados = novoCliente();
}
?>
<div class="container">
  <form method="POST" action="<?php echo $dados["url"] ?>" class="form-horizontal">
    <div class="form-group">
      <label class="col-sm-2">Nome</label>
      <div class="col-sm-10">
            <input type="text" name="nome" class="form-control" 
            placeholder="Digite o nome do Cliente" 
            value="<?php echo $dados['nome'] ?>"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Email</label>
      <div class="col-sm-10">
        <input type="text" name="email" class="form-control"
         value="<?php echo $dados['email']?>"placeholder="Digite o Email do Cliente" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-2">Senha</label>
      <div class="col-sm-10">
        <input type="text" name="senha" class="form-control" 
        value="<?php echo $dados['senha']?>"placeholder="Senha do Cliente"/>
        <input type="hidden" name="id" value="<?php echo $dados["id"]?>" />
      </div>
    </div>
   

    <input type="submit" class="btn btn-primary" value="Salvar" />
  </form>
</div>
<?php
include "templates/rodape.php";
?>
