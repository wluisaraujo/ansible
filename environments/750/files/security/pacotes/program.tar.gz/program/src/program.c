#include <stdio.h>

int main(){
        printf("=================================================================================");
        printf("\nThis is the steps to compile a program from the source code.\n");
        printf("=================================================================================");
        printf("\nEstes são os passos para se compilar um programa a partir do código fonte.\n");
        printf("=================================================================================");
}

