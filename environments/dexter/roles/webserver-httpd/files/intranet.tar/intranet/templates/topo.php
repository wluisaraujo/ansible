<?php
include "./utils/comuns.php";
validarSessao();
?>

<html>
<head><title>Aplicação Projetos</title></head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="http://intranet.dexter.com.br/">
         <img src="http://intranet.dexter.com.br/static/images/logo-dexter.png" style="width: 150px; height: 25px;" />
      </a>
    </div>
      <ul class="nav navbar-nav">
        <?php if($_SESSION['email'] != 'restrito@dexter.com.br'){ ?>
        <li><a href="projetos.php">Projetos</a></li>
        <li><a href="clientes.php">Clientes</a></li>
        <li><a href="usuarios.php">Usuarios</a></li>
        <?php } ?>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><?php echo $_SESSION['nome']; ?></a></li>
        <li><a href="logout.php">Sair</a></li>        
      </ul>
  </div>
</nav>
